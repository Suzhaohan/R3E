I would like you to implement a module named `TopModule` with the following interface. All input and output ports are one bit unless otherwise specified.

### Inputs:
- `clk`: System clock signal.
- `rst_n`: Asynchronous reset signal, active low.
- `data`: Single-bit input signal, representing the data to be checked.

### Outputs:
- `match`: A signal that outputs `1` when the input signal `data` matches the target sequence `011100`. It remains `0` at all other times.
- `not_match`: A signal that outputs `1` when the input signal `data` does not match the target sequence `011100`. It remains `0` at all other times.

### Module Description:
The module must detect the sequence `011100` from the input signal `data`. Please use the state machine to solve this problem. The detection rules are as follows:
1. The sequence check begins with every sixth bit of input data, meaning the module processes the input in groups of six bits and does not overlap or reuse bits between groups.
2. If the first bit of a group does not match the sequence, the module skips the entire group and starts checking from the next group beginning at the seventh bit.
3. When the sequence `011100` is detected, the `match` output should assert (go high).
4. If the sequence is not detected in a group, the `not_match` output should assert (go high).

### Output Logic:
The output signals `match` and `not_match` should be implemented as follows:
- Declare both outputs as `reg` type: `output reg match, output reg not_match`
- Use combinational logic with Wildcard Sensitivity List block to control the outputs
- The outputs are mutually exclusive - only one can be high at a time

### Timing and Behavior:
- When `rst_n` is low, the module should reset to its initial state and begin sequence detection from the start.
- On every positive clock edge (`clk`), the module should evaluate the input signal `data` and transition states accordingly.


## Prospective development timing contract

Inputs are binary. Reset is active low and asynchronous. Data is stable before
each rising edge; it may change between edges. Every rising edge with reset high
consumes exactly one bit. From each reset, groups are six bits long with no idle
cycle between groups. Immediately after bit six, outputs classify that group:
match for 011100, otherwise not_match. Both are zero after the other five edges.
Reset discards a partial group and clears outputs. Outputs remain defined and
exclusive and do not depend on an unevaluated new data value between edges.

