module formal_top;
(* anyconst *) reg a;
(* anyconst *) reg b;
(* anyconst *) reg s;
wire [0:0] actual, expected;
mux21 dut(.a(a),.b(b),.s(s),.y(actual[0]));
r3e_reference oracle(.a(a),.b(b),.s(s),.y(expected[0]));
always @* assert(actual == expected);
endmodule
module r3e_reference(a,b,s,y);
	input a,b,s;
	output y;
	reg y;
	always @(a,b,s)
    
        

begin
         case(s)
         1'b0:begin y = a;end
          1'b1:begin y = b;end
          default:begin y = 0;end
          endcase
end
        

	
endmodule