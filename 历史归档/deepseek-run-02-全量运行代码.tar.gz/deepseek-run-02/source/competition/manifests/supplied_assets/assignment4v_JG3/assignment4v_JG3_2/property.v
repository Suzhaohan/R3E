module formal_top;
(* anyconst *) reg [2:0] ABC;
wire [1:0] actual, expected;
JG3 dut(.ABC(ABC),.X(actual[0]),.Y(actual[1]));
r3e_reference oracle(.ABC(ABC),.X(expected[0]),.Y(expected[1]));
always @* assert(actual == expected);
endmodule
module r3e_reference(ABC,X,Y);
	
	input [2:0] ABC;
	
	output X, Y;
	reg X, Y;
	
	always@(ABC)
    
        

		case(ABC)
		3'B000:begin X<=1'B0;Y<=1'B1;end
		3'B001:begin X<=1'B0;Y<=1'B0;end
		3'B010:begin X<=1'B0;Y<=1'B0;end
		3'B011:begin X<=1'B0;Y<=1'B0;end
		3'B100:begin X<=1'B0;Y<=1'B0;end
		3'B101:begin X<=1'B1;Y<=1'B0;end
		3'B110:begin X<=1'B1;Y<=1'B0;end
		default:begin X<=1'B1;Y<=1'B0;end
		endcase
		
        

	
endmodule