module tb;
reg [2:0] a;
reg ena;
wire [7:0] actual, expected;
decoder3e_test dut(.a(a),.ena(ena),.y(actual[7:0]));
r3e_reference oracle(.a(a),.ena(ena),.y(expected[7:0]));
integer i, fd, bad, first;
initial begin
 fd=$fopen("output.csv","w"); $fdisplay(fd,"time,actual"); bad=0; first=-1;
 for(i=0;i<16;i=i+1) begin
  {a,ena}=i; #1; $fdisplay(fd,"%0d,%b",i,actual);
  if(actual !== expected) begin bad=bad+1; if(first<0) first=i; end
 end
 $fclose(fd);
 if(bad==0) begin
  $display("R3E_ORACLE pass=1 signature=none first=none topology=none");
  $display("R3E_WAVEFORM signal=none first_cycle=none cycle_offset=none relation=none assignment=none cone_depth=none pattern=none");
 end else begin
  $display("R3E_ORACLE pass=0 signature=output_mismatch first=vector%0d topology=actual",first);
  $display("R3E_WAVEFORM signal=actual first_cycle=%0d cycle_offset=0 relation=same_cycle assignment=procedural cone_depth=1 pattern=output_mismatch",first);
 end
 $finish;
end
endmodule


module r3e_reference(a,ena,y);
  input [2:0] a;
  input ena;
  output reg [7:0] y; 

  


always@(ena or a)
casex ({ena,a}) 
  4'b0xxx:y=8'b00000000;
  4'b1000:y=8'b00000001;
  4'b1001:y=8'b00000010;
  4'b1010:y=8'b00000100;
  4'b1011:y=8'b00001000;
  4'b1100:y=8'b00010000;
  4'b1101:y=8'b00100000;
  4'b1110:y=8'b01000000;
  4'b1111:y=8'b10000000;
endcase


endmodule
