"""Use remaining supplied functional versions without leaking final designs into evolution."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import re
import subprocess
import tempfile

from competition.arena.evidence import read
from competition.arena.isolation import check_separation
from r3e.arena.manifests import make_manifest, freeze_manifest
from r3e.blue.portfolio.oracle_gate_verifier import public_case_from_manifest
from r3e.protocol.hashing import hash_file, hash_payload, atomic_write_json
from r3e.semantic_repair_bench.oracle_gate import judge
from r3e.red.grounded.verilog_ast import tokenize_verilog, VerilogAstViolation


def build(root):
    root = Path(root).resolve()
    directory = root / "competition/manifests"
    # Recover dependencies that the earlier export omitted, from the user's
    # supplied snapshot. The resulting package is self-contained thereafter.
    upstream = root.parents[1] / "verilog_repair-master/benchmarks"
    recovered = []
    for name in ("opencores/pairing/tate_pairing.v", "opencores/i2c/timescale.v", "opencores/i2c/i2c_master_defines.v"):
        target = root / "datasets/cases/cirfix" / name
        original_asset = upstream / name
        if not target.exists() and original_asset.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(original_asset.read_bytes())
        if target.is_file():
            recovered.append({"path": str(target.relative_to(root)), "sha256": hash_file(target),
                              "source": "verilog_repair-master/benchmarks/" + name})
    heldout = read(directory / "red_heldout_v2.json")
    supplied = read(directory / "supplied_defect_assets_v1.json")
    regression = read(directory / "red_regression_v2.json")
    strider = read(directory / "strider14_sealed.json")
    seen, inventory, pending = {}, [], []
    def identity(row):
        return (hash_file(root / row["buggy_rtl"]), hash_file(root / row["golden_rtl"]))
    for usage, manifest in (("evolution", supplied), ("regression", regression), ("heldout", heldout), ("strider14", strider)):
        for row in manifest["rows"]:
            seen[identity(row)] = {"case_id": row["case_id"], "usage": usage}
    for dataset in ("cirfix39", "literature32"):
        for line in (root / f"datasets/manifests/{dataset}.jsonl").read_text().splitlines():
            original = json.loads(line)
            record = {"dataset": dataset, "source_case_id": original["case_id"], "buggy_rtl": original["buggy_rtl"]}
            row = dict(original)
            buggy = root / row["buggy_rtl"]
            golden = row.get("golden_rtl") or row.get("reference_path")
            if not golden:
                basename = re.split(r"_(?:wadden|kgoliya|ssscrazy)_buggy", buggy.stem)[0] + ".v"
                inferred = buggy.parent / basename
                golden = str(inferred.relative_to(root)) if inferred.exists() and inferred != buggy else ""
            if not golden or not (root / golden).is_file():
                inventory.append({**record, "status": "unavailable", "reason": "missing_reference_rtl"})
                continue
            row["golden_rtl"] = golden
            key = identity(row)
            if key in seen:
                inventory.append({**record, "status": "alias_of_existing_case", **seen[key]})
                continue
            case_id = f"supplied:{dataset}:{original['case_id']}"
            family = original["design"].split("__")[0]
            row.update(case_id=case_id, design="supplied:" + family, design_group="supplied:" + family,
                poison_id=case_id, normalized_diff_hash=hash_payload({"buggy": key[0], "golden": key[1]}),
                failure_signature=hash_payload({"supplied_case": case_id}), source_kind="public_supplied_functional",
                source_design_name=family)
            golden_source = (root / golden).read_text()
            modules = re.findall(r"\bmodule\s+(\w+)", re.sub(r"/\*.*?\*/|//[^\n]*", "", golden_source, flags=re.DOTALL))
            if row.get("top_module") not in modules and len(modules) != 1:
                inventory.append({**record, "status": "unavailable", "reason": "ambiguous_repair_module"})
                continue
            row["top_module"] = row.get("top_module") if row.get("top_module") in modules else modules[0]
            # Native CirFix testbench names its CSV output. Keep its stimuli and dependencies.
            tb = row.get("tb_sources") or row.get("testbench_files") or []
            outputs = sorted({name for p in tb for name in re.findall(r'\$fopen\s*\(\s*"([^"\n]+)"', (root / p).read_text())})
            if len(outputs) != 1:
                inventory.append({**record, "status": "unavailable", "reason": "ambiguous_or_missing_trace_output", "outputs": outputs})
                continue
            row["tb_output"] = outputs[0]
            # The original manifest sometimes lists the replaced module as a dependency.
            row["tb_sources"] = [p for p in tb if p not in {golden, row["buggy_rtl"]}]
            row["deps"] = [p for p in row.get("deps", []) if p not in {golden, row["buggy_rtl"]}]
            if original["design"] == "i2c":
                for filename in ("timescale.v", "i2c_master_defines.v", "i2c_slave_model.v"):
                    dependency = str((buggy.parent / filename).relative_to(root))
                    if dependency not in {golden, row["buggy_rtl"], *row["deps"], *row["tb_sources"]}:
                        row["deps"].append(dependency)
            try:
                case = public_case_from_manifest(row, project_root=root)
            except (ValueError, RuntimeError) as exc:
                inventory.append({**record, "status": "unavailable", "reason": str(exc)})
                continue
            row["manifest_file_hashes"] = case["manifest_file_hashes"]
            seen[key] = {"case_id": case_id, "usage": "final_heldout_pending_qualification"}
            pending.append((record, row, case))
    def qualify(item):
        record, row, case = item
        with tempfile.TemporaryDirectory(prefix="r3e-resource-qualification-") as tmp:
            outcome = judge(case, case["buggy_rtl_path"], tmp, evidence_k=3)
            qualified = outcome.stage == "compare" and not outcome.ok
            if qualified:
                try:
                    tokenize_verilog(case["buggy_rtl_source"])
                    tokenize_verilog(Path(case["golden_rtl"]).read_text())
                except VerilogAstViolation:
                    # Expand Verilog macros with the real compiler; preserve both
                    # original sources and require byte-identical output traces.
                    original_case = case
                    derived = directory / "supplied_preprocessed" / row["case_id"].replace(":", "_")
                    derived.mkdir(parents=True, exist_ok=True)
                    provenance = {}
                    for role, key in (("buggy", "buggy_rtl"), ("golden", "golden_rtl")):
                        original_path = root / row[key]
                        output = derived / (role + ".v")
                        run = subprocess.run(["iverilog", "-E", "-g2012", "-o", str(output), str(original_path)],
                            cwd=original_path.parent, capture_output=True, text=True, timeout=30)
                        if run.returncode:
                            raise ValueError("supplied macro preprocessing failed: " + run.stderr[:200])
                        tokenize_verilog(output.read_text())
                        provenance[role] = {"original": row[key], "original_sha256": hash_file(original_path)}
                        row[key] = str(output.relative_to(root))
                    row["preprocessing"] = {"tool": "iverilog -E -g2012", "sources": provenance}
                    case = public_case_from_manifest(row, project_root=root)
                    row["manifest_file_hashes"] = case["manifest_file_hashes"]
                    checked = judge(case, case["buggy_rtl_path"], Path(tmp) / "expanded", evidence_k=3)
                    if checked.stage != "compare" or checked.ok:
                        raise ValueError("macro expansion changed functional qualification")
                    for side in ("golden", "cand"):
                        if ((Path(tmp) / side / original_case["tb_output"]).read_bytes()
                                != (Path(tmp) / "expanded" / side / case["tb_output"]).read_bytes()):
                            raise ValueError("macro expansion changed observed behavior")
            result = {**record, "case_id": row["case_id"], "design": row["design"],
                "status": "final_heldout" if qualified else "unavailable",
                "reason": "functional_mismatch" if qualified else outcome.err.replace(tmp, "<qualification>") or "no_observable_failure",
                "stage": outcome.stage, "asset_hash": hash_payload(case["manifest_file_hashes"])}
            return result, row if qualified else None
    extra = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        for record, row in pool.map(qualify, pending):
            inventory.append(record)
            if row is not None:
                extra.append(row)
    # Aliases inherit the concrete qualification outcome; they are never double-counted.
    outcomes = {r.get("case_id"): r["status"] for r in inventory if r["status"] != "alias_of_existing_case"}
    for record in inventory:
        if record["status"] == "alias_of_existing_case" and record["usage"] == "final_heldout_pending_qualification":
            record["usage"] = outcomes[record["case_id"]]
    value = make_manifest(heldout["rows"] + extra, split="evaluation", metadata={
        **heldout["metadata"], "dataset_version": 3,
        "source_note": "Frozen public supplied defects plus synthetic protocol cases; not all cases were generated by this experiment's Red.",
        "additional_supplied_cases": len(extra), "qualification_inventory_hash": hash_payload(inventory),
        "design_count": len({r["design"] for r in heldout["rows"] + extra})})
    check_separation(supplied, value)
    check_separation(regression, value)
    freeze_manifest(directory / "red_heldout_v3.json", value)
    atomic_write_json(directory / "resource_inventory_v1.json", {"network_calls": 0,
        "recovered_supplied_assets": recovered,
        "rows": inventory, "status_counts": dict(Counter(r["status"] for r in inventory)),
        "qualification_inventory_hash": hash_payload(inventory), "heldout_manifest_hash": value["manifest_hash"],
        "syntax_only_resource": {"dataset": "rtlfixer50", "cases": 50,
                                 "usage": "separate syntax benchmark; excluded from this functional repair experiment"}})
    return {"additional_heldout": len(extra), "heldout_cases": value["row_count"],
            "status_counts": dict(Counter(r["status"] for r in inventory))}


if __name__ == "__main__":
    print(json.dumps(build(Path(__file__).resolve().parents[2]), ensure_ascii=False))
