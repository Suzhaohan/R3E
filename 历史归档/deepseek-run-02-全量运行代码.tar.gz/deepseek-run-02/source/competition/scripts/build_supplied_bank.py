"""Qualify every supplied version; freeze the actual RTL repair bank and inventory.

Public supplied defects are ordinary practice/validation cases, never relabeled
as newly generated Grounded Red poisons. No reference patch enters policy search.
"""
from collections import Counter
import json
from pathlib import Path
import tempfile

from competition.arena.evidence import read
from competition.arena.isolation import check_separation
from competition.scripts.expand_arena_designs import SPECS, grounded_wrapper
from r3e.arena.manifests import make_manifest, freeze_manifest
from r3e.blue.portfolio.oracle_gate_verifier import public_case_from_manifest
from r3e.protocol.hashing import hash_file, hash_payload, atomic_write_json
from r3e.semantic_repair_bench.oracle_gate import judge


def build(root):
    root = Path(root).resolve()
    manifests = root / "competition/manifests"
    original = [json.loads(line) for line in (root / "datasets/manifests/assignment4v57.jsonl").read_text().splitlines()]
    evolve = read(manifests / "red_evolve_v2.json")
    regression = read(manifests / "red_regression_v2.json")
    heldout = read(manifests / "red_heldout_v2.json")
    specs = {case_id.rsplit("_", 1)[0]: (inputs, outputs) for case_id, inputs, outputs in SPECS[:-1]}
    candidates = [grounded_wrapper(root, row, *specs[row["design"]], per_variant=True)
                  for row in original if row["design"] in specs]
    circ = [json.loads(line) for line in (root / "datasets/manifests/cirfix39.jsonl").read_text().splitlines()]
    for row in circ:
        if not row["design"].startswith("decoder_3_to_8__"):
            continue
        row = {**row, "case_id": "cirfix:" + row["design"], "design": "cirfix:decoder_3_to_8",
               "source_kind": "public_cirfix_input", "poison_id": "cirfix:supplied:" + row["case_id"],
               "normalized_diff_hash": hash_payload({"buggy": hash_file(root / row["buggy_rtl"]),
                                                       "golden": hash_file(root / row["golden_rtl"])}),
               "failure_signature": hash_payload({"supplied_cirfix": row["case_id"]})}
        candidates.append(grounded_wrapper(root, row, *SPECS[-1][1:], per_variant=True))
    admitted, qualifications = [], []
    with tempfile.TemporaryDirectory(prefix="r3e-supplied-qualification-") as temporary:
        for index, row in enumerate(candidates):
            case = public_case_from_manifest(row, project_root=root)
            outcome = judge(case, case["buggy_rtl_path"], Path(temporary) / str(index), evidence_k=6)
            qualified = not outcome.ok and outcome.stage == "compare"
            qualifications.append({"case_id": row["case_id"], "design": row["design"],
                "qualified": qualified, "stage": outcome.stage, "already_correct": outcome.ok,
                "reason": "functional_mismatch" if qualified else outcome.err or "no_observable_failure",
                "asset_hash": hash_payload(case["manifest_file_hashes"]), "mismatch": outcome.mismatch})
            if qualified:
                # Policy search receives identity and observable evidence only;
                # the adapter resolves immutable oracle assets privately by ID.
                admitted.append({key: row[key] for key in (
                    "case_id", "design", "poison_id", "normalized_diff_hash", "failure_signature")})
    assets = make_manifest(candidates, split="evolve", metadata={"allowed_usage": "evolution_only",
        "dataset": "supplied-existing-defects", "sealed": True, "red_generated": False})
    bank = make_manifest(admitted, split="evolve", metadata={"allowed_usage": "evolution_only", "sealed": True,
        "dataset": "supplied-repair-bank", "assets_manifest_hash": assets["manifest_hash"],
        "qualification_hash": hash_payload(qualifications), "red_generated": False})
    for other in (regression, heldout):
        check_separation(assets, other)
    if not {row["design"] for row in assets["rows"]} <= {row["design"] for row in evolve["rows"]}:
        raise ValueError("supplied cases lack fixed evolution design roles")
    freeze_manifest(manifests / "supplied_defect_assets_v1.json", assets)
    freeze_manifest(manifests / "supplied_repair_bank_v1.json", bank)
    atomic_write_json(manifests / "supplied_qualification_v1.json", {
        "schema_version": "r3e-supplied-qualification-v1", "network_calls": 0,
        "qualification_hash": hash_payload(qualifications), "rows": qualifications})
    assignments = []
    accepted = {r["case_id"] for r in admitted}
    for row in original:
        if row["design"] in specs:
            usage = "practice_or_promotion_target" if row["case_id"] in accepted else "excluded_with_qualification_reason"
        else:
            usage = "non_target_regression" if row["design_family"] == "latch24" else "final_heldout"
        assignments.append({"case_id": row["case_id"], "design": row["design"], "usage": usage})
    inventory = {"schema_version": "r3e-supplied-resource-inventory-v1", "assignment_rows": assignments,
        "assignment_usage_counts": dict(Counter(r["usage"] for r in assignments)),
        "bank_case_count": bank["row_count"], "bank_design_count": len({r["design"] for r in admitted}),
        "bank_hash": bank["manifest_hash"], "assets_hash": assets["manifest_hash"],
        "qualification_hash": hash_payload(qualifications), "network_calls": 0}
    atomic_write_json(manifests / "supplied_inventory_v1.json", inventory)
    return inventory


if __name__ == "__main__":
    print(json.dumps(build(Path(__file__).resolve().parents[2]), ensure_ascii=False, indent=2))
