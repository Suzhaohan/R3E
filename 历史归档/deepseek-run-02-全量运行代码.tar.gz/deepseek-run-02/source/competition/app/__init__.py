"""Competition application entry points."""
